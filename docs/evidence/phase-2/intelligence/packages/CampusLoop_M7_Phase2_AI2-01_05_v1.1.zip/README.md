# CampusLoop M7 · Phase 2 修订交付 v1.1

2026-09-28。针对外部审查确认的跨平台换行缺陷，已固定 JSON/JSONL 的 LF 写入和 Git 检出规则，重建 derived 与 manifest；旧 v1 包保持不变。

- [评估结论、修复与运行说明](docs/evidence/phase-2/intelligence/portability-review.md)
- [五项个人任务总清单](docs/evidence/phase-2/intelligence/deliverables.md)
- [搜索与匹配服务契约](docs/evidence/phase-2/intelligence/search-service-contract.md)
- [匹配任务契约](docs/evidence/phase-2/intelligence/matching-task-contract.md)
- [接收清单及准确分支名称](docs/evidence/phase-2/intelligence/contract-handoff.md)

当前数据版本：m7-synthetic-p2-v1.1；schema、标签和业务语义未变。原始数据、schema、契约样例、依赖锁保持原字节；处理数据中的 9 个 JSON/JSONL 文件从 CRLF 改为 LF，CSV 原本就是 LF，保持不变；manifest 随版本和哈希重新生成。没有改 ownerId。

验证：28 项数据测试、53 项契约测试及 22 个样例通过；LF/CRLF 默认写入规则模拟的全量构建字节一致；真实 Git core.autocrlf=true/false 检出后资产不变且 verify 通过。官方索引六个锁定依赖的 wheel 下载成功，本机独立依赖目录运行通过。

当前没有 Linux/macOS 实机环境，上述结果不冒充这些平台的实际执行；M10 仍需在目标环境复现。用户确认 228/228 对人工复核全部正确，原标签无需修改；逐条记录待归档，成员签字仍待完成。通知与真实数据库联调状态未变。仓库个人分支已上传，本次修订更新现有 [草稿 PR #87](https://github.com/Huang0283/CampusLoop/pull/87)。

本轮原始证据：[运行记录](evidence/portability-v1.1/run-record.json)、[数据测试](evidence/portability-v1.1/data-tests.log)、[契约测试](evidence/portability-v1.1/contracts-tests.log)、[语义/字节对比](evidence/portability-v1.1/semantic-comparison.json)、[Git 检出核查](evidence/portability-v1.1/git-checkout-comparison.json)。evidence/contracts-v1/ 与 evidence 根目录旧日志是历史材料，不是本次修订记录。

文件校验值见 FILES.sha256.json。依赖镜像缺版本时的官方索引命令见运行说明，不直接修改锁定版本。

2026-10-08 文档修订：数据版本名称统一为 `m7-synthetic-p2-v1.1`；旧活动交付包由本包替换。数据、标签、算法和历史运行日志未改变。[人工复核状态](docs/evidence/phase-2/intelligence/human-review-status.md) 记录用户确认与空白辅助表的检查结果；辅助表不是已填写的复核凭证。
